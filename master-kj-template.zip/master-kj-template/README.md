# Master KJ

AI assistant starter project.

## Run

npm install
npm run dev
